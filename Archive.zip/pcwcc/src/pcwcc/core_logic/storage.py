from __future__ import annotations

import json
import os
import re
import time
from typing import Optional

from platformdirs import user_config_dir

from .models import DEFAULT_PARAMS, DeviceInfo, DeviceParams
from .protocol import APP_NAME


def _ensure_app_config_dir() -> str:
    path = user_config_dir(APP_NAME, ensure_exists=True)
    os.makedirs(path, exist_ok=True)
    return path


APP_CONFIG_DIR = _ensure_app_config_dir()
PAIRED_DB = os.path.join(APP_CONFIG_DIR, "paired_devices.json")
HOST_KEY_PATH = os.path.join(APP_CONFIG_DIR, "host_key.pem")
PARAMS_DB = os.path.join(APP_CONFIG_DIR, "params.json")
METRICS_HISTORY_DIR = os.path.join(APP_CONFIG_DIR, "metrics_history")
METRICS_HISTORY_WINDOW_SECONDS = 30 * 60


def _safe_history_name(address: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", address.strip())
    return value or "__unknown__"


def metrics_history_path(address: str) -> str:
    return os.path.join(METRICS_HISTORY_DIR, f"{_safe_history_name(address)}.json")


def _filter_metric_points(
    points: list[dict],
    now: Optional[float] = None,
    window_seconds: int = METRICS_HISTORY_WINDOW_SECONDS,
) -> list[dict]:
    current = time.time() if now is None else now
    min_ts = current - window_seconds
    filtered: list[dict] = []
    for item in points:
        if not isinstance(item, dict):
            continue
        try:
            timestamp = float(item["timestamp"])
        except (KeyError, TypeError, ValueError):
            continue
        if timestamp < min_ts or timestamp > current + 60:
            continue
        filtered.append(
            {
                "timestamp": timestamp,
                "fan_percent": item.get("fan_percent"),
                "temp4_c": item.get("temp4_c"),
                "temp3_c": item.get("temp3_c"),
            }
        )
    filtered.sort(key=lambda point: point["timestamp"])
    return filtered


def load_metrics_history(address: str, now: Optional[float] = None) -> list[dict]:
    path = metrics_history_path(address)
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as handle:
            raw = json.load(handle)
        if not isinstance(raw, list):
            return []
    except Exception:
        return []
    points = _filter_metric_points(raw, now=now)
    save_metrics_history(address, points, now=now)
    return points


def load_metrics_history_all(address: str) -> list[dict]:
    path = metrics_history_path(address)
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as handle:
            raw = json.load(handle)
        if not isinstance(raw, list):
            return []
    except Exception:
        return []
    points: list[dict] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        try:
            timestamp = float(item["timestamp"])
        except (KeyError, TypeError, ValueError):
            continue
        points.append(
            {
                "timestamp": timestamp,
                "fan_percent": item.get("fan_percent"),
                "temp4_c": item.get("temp4_c"),
                "temp3_c": item.get("temp3_c"),
            }
        )
    points.sort(key=lambda point: point["timestamp"])
    return points


def save_metrics_history(address: str, points: list[dict], now: Optional[float] = None) -> None:
    os.makedirs(METRICS_HISTORY_DIR, exist_ok=True)
    filtered = _filter_metric_points(points, now=now)
    path = metrics_history_path(address)
    tmp_path = f"{path}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as handle:
        json.dump(filtered, handle, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)


def load_paired_records() -> list[dict]:
    if not os.path.exists(PAIRED_DB):
        return []
    try:
        with open(PAIRED_DB, "r", encoding="utf-8") as handle:
            raw = json.load(handle)
        if isinstance(raw, list):
            return raw
    except Exception:
        return []
    return []


def save_paired_records(records: list[dict]) -> None:
    with open(PAIRED_DB, "w", encoding="utf-8") as handle:
        json.dump(records, handle, ensure_ascii=False, indent=2)


def find_paired_record(address: str) -> Optional[dict]:
    for item in load_paired_records():
        if item.get("address") == address:
            return item
    return None


def update_paired_last_connected(address: str) -> None:
    raw = load_paired_records()
    now = int(time.time())
    changed = False
    for item in raw:
        if item.get("address") == address:
            item["last_connected"] = now
            changed = True
            break
    if changed:
        save_paired_records(raw)


def get_auto_connect_address() -> Optional[str]:
    for item in load_paired_records():
        if item.get("auto_connect") and item.get("address"):
            return str(item["address"])
    return None


def set_paired_auto_connect(address: str, enabled: bool) -> bool:
    raw = load_paired_records()
    changed = False
    found = False
    for item in raw:
        item_address = item.get("address")
        if not item_address:
            continue
        should_enable = bool(enabled and item_address == address)
        if item_address == address:
            found = True
        if bool(item.get("auto_connect", False)) != should_enable:
            item["auto_connect"] = should_enable
            changed = True
    if not found:
        return False
    if changed:
        save_paired_records(raw)
    return True


def add_or_update_paired(device: DeviceInfo, k_hex: str) -> None:
    raw = load_paired_records()
    for item in raw:
        if item.get("address") == device.address:
            item["name"] = device.name
            item["k_hex"] = k_hex
            if "last_connected" not in item:
                item["last_connected"] = 0
            if "auto_connect" not in item:
                item["auto_connect"] = False
            break
    else:
        raw.append(
            {
                "name": device.name,
                "address": device.address,
                "k_hex": k_hex,
                "last_connected": 0,
                "auto_connect": False,
            }
        )
    save_paired_records(raw)


def rename_paired_record(address: str, name: str) -> bool:
    normalized = name.strip()
    if not normalized:
        return False
    raw = load_paired_records()
    for item in raw:
        if item.get("address") == address:
            item["name"] = normalized
            save_paired_records(raw)
            return True
    return False


def _params_from_dict(raw: dict) -> Optional[DeviceParams]:
    try:
        return DeviceParams(
            fan_min_speed=int(raw.get("fan_min_speed", DEFAULT_PARAMS.fan_min_speed)),
            fan_control_type=int(raw.get("fan_control_type", DEFAULT_PARAMS.fan_control_type)),
            fan_max_temp=int(raw.get("fan_max_temp", DEFAULT_PARAMS.fan_max_temp)),
            fan_off_delta=int(raw.get("fan_off_delta", DEFAULT_PARAMS.fan_off_delta)),
            fan_start_temp=int(raw.get("fan_start_temp", DEFAULT_PARAMS.fan_start_temp)),
            fan_mode=int(raw.get("fan_mode", DEFAULT_PARAMS.fan_mode)),
            fan_monitoring_enabled=bool(
                raw.get("fan_monitoring_enabled", DEFAULT_PARAMS.fan_monitoring_enabled)
            ),
            fan2_monitoring_enabled=bool(
                raw.get("fan2_monitoring_enabled", DEFAULT_PARAMS.fan2_monitoring_enabled)
            ),
            fan3_monitoring_enabled=bool(
                raw.get("fan3_monitoring_enabled", DEFAULT_PARAMS.fan3_monitoring_enabled)
            ),
            fan4_monitoring_enabled=bool(
                raw.get("fan4_monitoring_enabled", DEFAULT_PARAMS.fan4_monitoring_enabled)
            ),
        )
    except Exception:
        return None


def _params_to_dict(params: DeviceParams) -> dict:
    return {
        "fan_min_speed": int(params.fan_min_speed),
        "fan_control_type": int(params.fan_control_type),
        "fan_max_temp": int(params.fan_max_temp),
        "fan_off_delta": int(params.fan_off_delta),
        "fan_start_temp": int(params.fan_start_temp),
        "fan_mode": int(params.fan_mode),
        "fan_monitoring_enabled": bool(params.fan_monitoring_enabled),
        "fan2_monitoring_enabled": bool(params.fan2_monitoring_enabled),
        "fan3_monitoring_enabled": bool(params.fan3_monitoring_enabled),
        "fan4_monitoring_enabled": bool(params.fan4_monitoring_enabled),
    }


def _load_params_db() -> dict:
    if not os.path.exists(PARAMS_DB):
        return {}
    try:
        with open(PARAMS_DB, "r", encoding="utf-8") as handle:
            raw = json.load(handle)
        if isinstance(raw, dict):
            return raw
    except Exception:
        return {}
    return {}


def _save_params_db(raw: dict) -> None:
    with open(PARAMS_DB, "w", encoding="utf-8") as handle:
        json.dump(raw, handle, ensure_ascii=False, indent=2)


def load_device_params(address: str) -> DeviceParams:
    raw = _load_params_db()
    item = raw.get(address)
    if isinstance(item, dict):
        params = _params_from_dict(item)
        if params is not None:
            return params
    return DEFAULT_PARAMS


def save_device_params(address: str, params: DeviceParams) -> None:
    raw = _load_params_db()
    raw[address] = _params_to_dict(params)
    _save_params_db(raw)


def load_params() -> DeviceParams:
    return load_device_params("__global__")


def save_params(params: DeviceParams) -> None:
    save_device_params("__global__", params)
