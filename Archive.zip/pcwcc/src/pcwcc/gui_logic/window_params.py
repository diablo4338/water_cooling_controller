from __future__ import annotations

import math

from ..core import (
    DeviceParams,
    FAN_CONTROL_DC,
    FAN_MODE_CONTINUOUS,
    load_device_params,
    save_device_params,
)
from .constants import FAN_MONITORING_KEYS, PARAM_FIELDS


class MainWindowParamsMixin:
    @staticmethod
    def _default_device_params() -> DeviceParams:
        return DeviceParams(
            fan_min_speed=10,
            fan_control_type=FAN_CONTROL_DC,
            fan_max_temp=45,
            fan_off_delta=2,
            fan_start_temp=35,
            fan_mode=FAN_MODE_CONTINUOUS,
            fan_monitoring_enabled=True,
            fan2_monitoring_enabled=True,
            fan3_monitoring_enabled=True,
            fan4_monitoring_enabled=True,
        )

    def _set_fan_status_indicator(self, channel: int, color: str) -> None:
        if channel < len(self.fan_status_indicators):
            self.fan_status_indicators[channel].setStyleSheet(
                f"background:{color}; border:1px solid #111827;"
            )

    def _set_fan_status_tooltip(self, channel: int, text: str) -> None:
        if channel < len(self.fan_status_indicators):
            self.fan_status_indicators[channel].setToolTip(text)

    def _set_device_status_indicator(self, color: str) -> None:
        if self.device_status_indicator is not None:
            self.device_status_indicator.setStyleSheet(
                f"background:{color}; border:1px solid #111827;"
            )

    def _set_temp_indicator(self, channel: int, color: str, text: str) -> None:
        if channel < len(self.temp_indicators):
            self.temp_indicators[channel].setStyleSheet(
                f"background:{color}; border:1px solid #111827;"
            )
            self.temp_indicators[channel].setToolTip(text)

    def _device_params_for_metrics(self) -> DeviceParams:
        if self._device_params_snapshot is not None:
            return self._device_params_snapshot
        device = self.model.state.connected_device
        if device:
            return load_device_params(device.address)
        return self._default_device_params()

    def _refresh_temp_indicators(self) -> None:
        max_temp = float(self._device_params_for_metrics().fan_max_temp)
        for channel, value in enumerate(self.temp_values):
            if value is None or not math.isfinite(value):
                self._set_temp_indicator(channel, "#6b7280", "NC")
                continue
            delta = max_temp - value
            if delta > 5.0:
                self._set_temp_indicator(channel, "#22c55e", f"{delta:.2f}C below max")
            elif value < max_temp:
                self._set_temp_indicator(channel, "#eab308", f"{delta:.2f}C below max")
            else:
                self._set_temp_indicator(channel, "#ef4444", "At or above max")

    def _reset_params_fields(self) -> None:
        params = self._default_device_params()
        self._device_params_snapshot = None
        self._params_update_lock = True
        try:
            for item in self.param_fields:
                spec = item["spec"]
                widget = item["widget"]
                value = getattr(params, spec["key"])
                if spec["kind"] == "enum":
                    idx = widget.findData(int(value))
                    widget.setCurrentIndex(idx if idx >= 0 else 0)
                else:
                    widget.setValue(value)
                widget.setEnabled(False)
            for idx, key in enumerate(FAN_MONITORING_KEYS):
                self.fan_monitor_checkboxes[idx].setChecked(bool(getattr(params, key)))
                self.fan_monitor_checkboxes[idx].setEnabled(False)
        finally:
            self._params_update_lock = False
        self._clear_apply_status()

    def _set_params_fields(
        self,
        params: DeviceParams,
        save: bool = True,
        apply_status: str | None = None,
        apply_status_text: str | None = None,
    ) -> None:
        if len(self.param_fields) != len(PARAM_FIELDS) or len(self.fan_monitor_checkboxes) != 4:
            return
        self._device_params_snapshot = params
        self._params_update_lock = True
        try:
            for item in self.param_fields:
                spec = item["spec"]
                widget = item["widget"]
                value = getattr(params, spec["key"])
                if spec["kind"] == "enum":
                    idx = widget.findData(int(value))
                    widget.setCurrentIndex(idx if idx >= 0 else 0)
                else:
                    widget.setValue(value)
                widget.setEnabled(True)
            for idx, key in enumerate(FAN_MONITORING_KEYS):
                self.fan_monitor_checkboxes[idx].setChecked(bool(getattr(params, key)))
                self.fan_monitor_checkboxes[idx].setEnabled(idx > 0)
        finally:
            self._params_update_lock = False
        if save and self.model.state.connected_device:
            from .. import gui as gui_module

            gui_module.save_device_params(self.model.state.connected_device.address, params)
        if apply_status is not None and apply_status_text is not None:
            self._set_apply_status(apply_status, apply_status_text)
        self._refresh_temp_indicators()

    def _current_params(self) -> DeviceParams:
        if len(self.param_fields) != len(PARAM_FIELDS) or len(self.fan_monitor_checkboxes) != 4:
            device = self.model.state.connected_device
            return load_device_params(device.address) if device else self._device_params_for_metrics()
        values: dict[str, object] = {}
        for item in self.param_fields:
            spec = item["spec"]
            widget = item["widget"]
            value = int(widget.currentData()) if spec["kind"] == "enum" else int(widget.value())
            values[spec["key"]] = value
        for idx, key in enumerate(FAN_MONITORING_KEYS):
            values[key] = self.fan_monitor_checkboxes[idx].isChecked()
        return DeviceParams(
            fan_min_speed=int(values["fan_min_speed"]),
            fan_control_type=int(values["fan_control_type"]),
            fan_max_temp=int(values["fan_max_temp"]),
            fan_off_delta=int(values["fan_off_delta"]),
            fan_start_temp=int(values["fan_start_temp"]),
            fan_mode=int(values["fan_mode"]),
            fan_monitoring_enabled=bool(values["fan_monitoring_enabled"]),
            fan2_monitoring_enabled=bool(values["fan2_monitoring_enabled"]),
            fan3_monitoring_enabled=bool(values["fan3_monitoring_enabled"]),
            fan4_monitoring_enabled=bool(values["fan4_monitoring_enabled"]),
        )

    def _on_params_changed(self, _) -> None:
        if self._params_update_lock:
            return
        device = self.model.state.connected_device
        if device is None or self.model.state.conn != self.ConnState.CONNECTED:
            return
        self.model.set_status("Parameters changed. Press Apply to write them.")
        self._apply_ui()
        self._refresh_temp_indicators()

    def _set_apply_status(self, kind: str, text: str) -> None:
        self._apply_status_kind = kind
        self._apply_status_text = text
        color = {
            "idle": "#6b7280",
            "ok": "#16a34a",
            "error": "#dc2626",
        }.get(kind, "#6b7280")
        if self.apply_status_label is not None:
            self.apply_status_label.setStyleSheet(f"color:{color};")
            self.apply_status_label.setText(text)
            self.apply_status_label.setToolTip(text)

    def _show_apply_result(self, kind: str, text: str) -> None:
        self._set_apply_status(kind, text)
        if hasattr(self, "_apply_status_timer") and self._apply_status_timer is not None:
            self._apply_status_timer.stop()
        self._apply_status_timer.start(5000)
        self._apply_ui()

    def _clear_apply_status(self) -> None:
        if hasattr(self, "_apply_status_timer") and self._apply_status_timer is not None:
            self._apply_status_timer.stop()
        self._set_apply_status("idle", "")
